import mmdpaimaya.natang
natang_sang = mmdpaimaya.natang.roem()