# mmdpaimaya v2.0.2

MMDのモデルをmayaの中に読み込んだり、mayaで作られたモデルをMMDモデルファイル(.pmx)に書き出したりするスクリプトです。

詳しい使い方の説明はこちら https://qiita.com/phyblas/items/53161a1d83ec3d81f649

![](https://phyblas.hinaboshi.com/rup/yami/2018/a04.jpg)
