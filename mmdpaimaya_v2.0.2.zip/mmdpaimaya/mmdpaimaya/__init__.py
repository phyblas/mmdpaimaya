# -*- coding: utf-8 -*-
u'''
mmdpaimaya v1.2
'''